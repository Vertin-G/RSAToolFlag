import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.security.*;
import javax.crypto.*;
import java.nio.charset.StandardCharsets;
import java.util.Random;

public class RSAToolFlagVersion {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(RSAToolFlagVersion::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("RSA 出题工具 - 随机生成 flag 并加密");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // 顶部输入和按钮区
        JPanel inputPanel = new JPanel(new FlowLayout());
        JTextField flagField = new JTextField(25);
        flagField.setEditable(false);
        JButton generateButton = new JButton("生成并加密 flag");
        inputPanel.add(new JLabel("明文 flag："));
        inputPanel.add(flagField);
        inputPanel.add(generateButton);
        frame.add(inputPanel, BorderLayout.NORTH);

        // 输出区面板
        JPanel outputPanel = new JPanel(new GridLayout(4, 1));

        // 公钥显示
        JTextArea publicKeyTextArea = createOutputArea("公钥");
        JButton copyPubKey = new JButton("复制公钥");
        outputPanel.add(wrapWithButton(publicKeyTextArea, copyPubKey));

        // 私钥显示
        JTextArea privateKeyTextArea = createOutputArea("私钥");
        JButton copyPriKey = new JButton("复制私钥");
        outputPanel.add(wrapWithButton(privateKeyTextArea, copyPriKey));

        // 密文显示
        JTextArea cipherTextArea = createOutputArea("加密结果（十六进制）");
        JButton copyCipher = new JButton("复制密文");
        outputPanel.add(wrapWithButton(cipherTextArea, copyCipher));

        // UTF-8 编码显示
        JTextArea utf8TextArea = createOutputArea("明文 UTF-8 编码（十六进制）");
        JButton copyUtf8 = new JButton("复制编码");
        outputPanel.add(wrapWithButton(utf8TextArea, copyUtf8));

        frame.add(outputPanel, BorderLayout.CENTER);

        // 生成密钥对
        KeyPair keyPair;
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048);
            keyPair = keyGen.generateKeyPair();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "密钥生成失败: " + e.getMessage());
            return;
        }

        // 显示密钥
        publicKeyTextArea.setText(bytesToHex(keyPair.getPublic().getEncoded()));
        privateKeyTextArea.setText(bytesToHex(keyPair.getPrivate().getEncoded()));

        // 点击生成并加密按钮
        KeyPair finalKeyPair = keyPair;
        generateButton.addActionListener(e -> {
            String flag = generateRandomFlag();
            flagField.setText(flag);

            byte[] flagBytes = flag.getBytes(StandardCharsets.UTF_8);
            utf8TextArea.setText(bytesToHex(flagBytes));

            try {
                Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                cipher.init(Cipher.ENCRYPT_MODE, finalKeyPair.getPublic());
                byte[] encryptedBytes = cipher.doFinal(flagBytes);
                cipherTextArea.setText(bytesToHex(encryptedBytes));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "加密失败: " + ex.getMessage());
            }
        });

        // 复制功能绑定
        copyPubKey.addActionListener(e -> copyToClipboard(publicKeyTextArea.getText()));
        copyPriKey.addActionListener(e -> copyToClipboard(privateKeyTextArea.getText()));
        copyCipher.addActionListener(e -> copyToClipboard(cipherTextArea.getText()));
        copyUtf8.addActionListener(e -> copyToClipboard(utf8TextArea.getText()));

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // 工具函数：生成随机 flag{...}
    private static String generateRandomFlag() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder("flag{");
        Random rand = new SecureRandom();
        for (int i = 0; i < 8; i++) {
            sb.append(chars.charAt(rand.nextInt(chars.length())));
        }
        sb.append('}');
        return sb.toString();
    }

    // 工具函数：创建输出区域
    private static JTextArea createOutputArea(String title) {
        JTextArea area = new JTextArea(4, 40);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        return area;
    }

    // 工具函数：输出框 + 复制按钮布局
    private static JPanel wrapWithButton(JTextArea area, JButton button) {
        JPanel panel = new JPanel(new BorderLayout());
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBorder(BorderFactory.createTitledBorder(button.getText().replace("复制", "")));
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(button, BorderLayout.SOUTH);
        return panel;
    }

    // 字节数组转十六进制
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    // 复制到剪贴板
    private static void copyToClipboard(String text) {
        Toolkit.getDefaultToolkit()
                .getSystemClipboard()
                .setContents(new StringSelection(text), null);
        JOptionPane.showMessageDialog(null, "已复制到剪贴板！");
    }
}
